package com.example.justplayhelper

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private var timer: CountDownTimer? = null
    private var durationMs = 30_000L
    private var remainingMs = durationMs
    private lateinit var countdown: TextView
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var durationLabel: TextView
    private lateinit var seek: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(26, 34, 26, 26)
        }
        root.addView(TextView(this).apply {
            text = "JustPlay Helper"; textSize = 28f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
        }, params())
        root.addView(TextView(this).apply {
            text = "Temporizador e lembretes para Android"; textSize = 16f; gravity = Gravity.CENTER
            setPadding(0, 12, 0, 20)
        }, params())
        countdown = TextView(this).apply { text = fmt(remainingMs); textSize = 46f; gravity = Gravity.CENTER }
        root.addView(countdown, params())
        durationLabel = TextView(this).apply { text = "Duração: 30 segundos"; textSize = 16f }
        root.addView(durationLabel, params())
        seek = SeekBar(this).apply { max = 175; progress = 25 }
        root.addView(seek, params())
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                if (timer == null) {
                    durationMs = (p + 5) * 1000L; remainingMs = durationMs
                    countdown.text = fmt(remainingMs)
                }
                durationLabel.text = "Duração: ${p + 5} segundos"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        startButton = Button(this).apply { text = "Iniciar temporizador" }
        root.addView(startButton, params())
        startButton.setOnClickListener { startTimer() }
        root.addView(Button(this).apply { text = "Parar / Reiniciar" }, params()).setOnClickListener {
            timer?.cancel(); timer = null; remainingMs = durationMs
            countdown.text = fmt(remainingMs); status.text = "Temporizador parado."; startButton.isEnabled = true
        }
        status = TextView(this).apply {
            text = "Pronto. Usa o temporizador como lembrete."; textSize = 16f
            gravity = Gravity.CENTER; setPadding(0, 20, 0, 8)
        }
        root.addView(status, params())
        root.addView(TextView(this).apply {
            text = "Esta versão não clica nem avança anúncios. A validação de recompensas depende da JustPlay."
            textSize = 13f; gravity = Gravity.CENTER; setPadding(0, 18, 0, 0)
        }, params())
        setContentView(root)
    }

    private fun startTimer() {
        timer?.cancel()
        startButton.isEnabled = false
        status.text = "Temporizador ativo. Segue as instruções apresentadas no anúncio."
        timer = object : CountDownTimer(remainingMs, 250) {
            override fun onTick(ms: Long) { remainingMs = ms; countdown.text = fmt(ms) }
            override fun onFinish() {
                timer = null; remainingMs = 0; countdown.text = "00:00"
                status.text = "Tempo terminado. Verifica o ecrã."
                startButton.isEnabled = true
            }
        }.start()
    }

    private fun fmt(ms: Long): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d".format(sec / 60, sec % 60)
    }

    private fun params() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }
}
