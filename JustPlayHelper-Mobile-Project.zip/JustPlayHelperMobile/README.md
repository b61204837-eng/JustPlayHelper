# JustPlay Helper

Projeto Android com temporizador ajustável. Não automatiza anúncios nem gera recompensas.
Para gerar APK: abrir esta pasta no Android Studio num computador e escolher Build > Build APK(s).
